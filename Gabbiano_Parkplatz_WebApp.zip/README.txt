GABBIANO PARKPLATZ-WEB-APP

1. Öffnen Sie die Datei index.html im Browser.
2. Auf Android in Chrome: Menü (drei Punkte) > „Zum Startbildschirm hinzufügen“.
3. Kennzeichen werden lokal auf dem jeweiligen Gerät gespeichert.
4. Über „Als PDF drucken“ kann die Tagesliste als PDF gespeichert werden.
5. Über „CSV herunterladen“ kann eine Excel-kompatible Liste gespeichert werden.
6. „E-Mail vorbereiten“ öffnet die E-Mail-App mit allen Kennzeichen im Nachrichtentext.

WICHTIG:
Damit die App dauerhaft über einen Internet-Link erreichbar ist, muss der Ordner bei einem Webhoster
hochgeladen werden. Lokal funktioniert sie direkt auf PC; auf Smartphones ist ein Hosting-Link meist einfacher.
